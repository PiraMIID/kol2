#include "employee.h"
#include "address.h"
int main()
{
printf("program works\n");
}
